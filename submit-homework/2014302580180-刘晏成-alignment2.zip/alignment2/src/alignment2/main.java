package alignment2;
import java.io.File;
import java.io.FileWriter;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class main {
	public static void main(String[] args)throws IOException{
		File input = new File("Teacher.html");
		Document doc = Jsoup.parse(input, "UTF-8", "http://staff.whu.edu.cn/show.jsp?n=Ai Xin Ping&lang=cn");
		String title = doc.title();
		Elements txt = doc.select("p");
        Element content = doc.getElementById("content");
        String text = doc.body().text();
        FileWriter fw = new FileWriter("Teacher.txt");
        fw.write(title);
        fw.write(text);
        fw.close();
	}

}
